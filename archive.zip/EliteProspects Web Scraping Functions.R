library(XML)
library(stringr)

getPlayerDetails <- function(playerID) {
  
  URL <- paste("http://www.eliteprospects.com/player.php?player=", as.character(playerID), sep = "")
  
  #load all the text
  txt <- scan(URL, what = "raw", sep = "&")
  
  # handle the player name
  player.name <- gsub("<title>", "", txt[4], fixed = TRUE) 
  player.name <- gsub("-.*", "", player.name) %>% str_trim(side = "both")
  
  # handle the birthday
  regexp <- "[0-9]{4}-[0-9]{2}-[0-9]{2}"
  bday <- as.Date(unlist(str_extract(txt[6], regexp))) 
  
  # break down the HTML by line splits
  txt.split <- unlist(strsplit(txt, "\n"))
  
  # nation is in element 1836
  chars <- unlist(strsplit(txt.split[1836], ""))
  start.char <- which(chars == ">")[2] + 1
  chars <- chars[start.char:length(chars)]
  end.char <- which(chars == "<")[1] - 1
  chars <- chars[1:end.char]
  
  nation <- paste(chars, collapse = "")
  
  # position is in element 1840
  chars <- unlist(strsplit(txt.split[1840], ""))
  start.char <- which(chars == ">")[1] + 1
  chars <- chars[start.char:length(chars)]
  end.char <- which(chars == "<")[1] - 1
  chars <- chars[1:end.char]
  
  position <- paste(chars, collapse = "")
  
  # shoots is in element 1842
  chars <- unlist(strsplit(txt.split[1842], ""))
  start.char <- which(chars == ">")[1] + 1
  chars <- chars[start.char:length(chars)]
  end.char <- which(chars == "<")[1] - 1
  chars <- chars[1:end.char]
  
  shoots <- paste(chars, collapse = "")
  
  # height is in element 1846
  chars <- unlist(strsplit(txt.split[1846], ""))
  start.char <- which(chars == ">")[1] + 1
  chars <- chars[start.char:length(chars)]
  end.char <- which(chars == "<")[1] - 1
  chars <- chars[1:end.char]
  
  height <- paste(chars, collapse = "")
  
  # weight is in element 1848
  chars <- unlist(strsplit(txt.split[1848], ""))
  start.char <- which(chars == ">")[1] + 1
  chars <- chars[start.char:length(chars)]
  end.char <- which(chars == "<")[1] - 1
  chars <- chars[1:end.char]
  
  weight <- paste(chars, collapse = "")
  
  
  
  
  
  rtn <- data.frame(
    playerID = playerID, 
    playerName = player.name, 
    birthDay = bday,
    nation = nation,
    position = position,
    shoots = shoots,
    height = height,
    weight = weight
  )
  
  return(rtn)
}

getLeagueStats <- function(season, league) {
  # add handling to season in case it is passed as a number
  season <- as.character(season)
  
  # create a placeholder for the data
  playerStats <- data.frame()
  
  # construct a base URL
  base.URL <- "http://www.eliteprospects.com/league.php?currentpage=PAGEID&season=LEAGUEYEAR&leagueid=LEAGUENAME&pos=&leagueteam=&teamname=&nation=&nationname=&age=&prospects=&order="
  
  # need to loop through all of the pages - to determine how many pages, we need to know 
  # how many players there are and divide that by 100
  
  URL <- str_replace(base.URL, "PAGEID", "1") %>% 
    str_replace("LEAGUEYEAR", season) %>%
    str_replace("LEAGUENAME", league)
  
  # get the page HTML code
  txt <- scan(URL, what = "raw", sep = "&")
  
  # get index of the line that has the text " players found "
  p.ind <- which(grepl(" players found ", txt))
  
  # which line in that piece of text is the text on
  txt.split <- unlist(strsplit(txt[p.ind], "\n"))
  p.ind2 <- which(grepl(" players found ", txt.split))
  
  # get the number of players in the table for the given league and season
  players <- str_extract(str_extract(txt.split[p.ind2], "<strong>[0-9]{2,5}</strong>"), "[0-9]{2,5}")
  
  # calculate the number of pages in the table
  maxPages <- ceiling(as.numeric(players)/100)
  
  # now that we know how many pages there are, we can loop through each of them
  for (i in 1:maxPages){
    URL <- str_replace(base.URL, "PAGEID", as.character(i)) %>% 
      str_replace("LEAGUEYEAR", season) %>%
      str_replace("LEAGUENAME", league)
    
    pageHTML <- scan(URL, what = "raw", sep = "&")
    
    # find where in the HTML the PLAYER STATS table begins
    start <- which(grepl("PLAYER STATS", pageHTML))
    
    # trim the text down so it's only the table underneath of where you find PLAYER STATS
    HTML.split <- unlist(strsplit(pageHTML, "\n"))
    HTML.start <- which(grepl("PLAYER STATS", HTML.split))
    HTML.end <- length(HTML.split)
    HTML.trimmed <- paste(paste(HTML.split[HTML.start:HTML.end], collaspe = ""), collapse = "")
    
    # break the HTML data down into table rows (tag: tr)
    HTML.rows <- unlist(strsplit(HTML.trimmed, "<tr", fixed = TRUE))
    
    # create a blank data frame to push rows into
    pageData <- data.frame()
    
    # starting with row 4 (because rows 1:3 do not contain player data but rather 
    # some aethetic information for setting up the table), break each row down 
    # into its dimensions.
    for (j in 4:length(HTML.rows) - 1) {
      HTML.dims <- unlist(strsplit(HTML.rows[j], "<td", fixed = TRUE))
      if (length(HTML.dims) == 11) {
        # dim #3 has the player ID
        playerID <- as.numeric(str_extract(str_extract(HTML.dims[3], "player=[0-9]{1,9}"), "[0-9]{1,9}"))
        if (!is.na(playerID)) {
          # dim #4 has the team name
          chars <- unlist(strsplit(HTML.dims[4], ""))
          first.char <- min(which(grepl(">", chars))) + 1
          chars <- chars[first.char:length(chars)]
          last.char <- min(which(grepl("<", chars))) - 1
          chars <- chars[1:last.char]
          
          teamName <- paste(chars, collapse = "")
          if (teamName == "<") {
            teamName <- "Multiple Teams"
          }
          
          # dim #5 has the GP
          chars <- unlist(strsplit(HTML.dims[5], ""))
          first.char <- min(which(grepl(">", chars))) + 1
          chars <- chars[first.char:length(chars)]
          last.char <- min(which(grepl("<", chars))) - 1
          chars <- chars[1:last.char]
          
          GP <- as.numeric(paste(chars, collapse = ""))
          
          # dim #6 has the G
          chars <- unlist(strsplit(HTML.dims[6], ""))
          first.char <- min(which(grepl(">", chars))) + 1
          chars <- chars[first.char:length(chars)]
          last.char <- min(which(grepl("<", chars))) - 1
          chars <- chars[1:last.char]
          
          G <- as.numeric(paste(chars, collapse = ""))
          
          # dim #7 has the A
          chars <- unlist(strsplit(HTML.dims[7], ""))
          first.char <- min(which(grepl(">", chars))) + 1
          chars <- chars[first.char:length(chars)]
          last.char <- min(which(grepl("<", chars))) - 1
          chars <- chars[1:last.char]
          
          A <- as.numeric(paste(chars, collapse = ""))
          
          # dim #8 has the PTS
          # chars <- unlist(strsplit(HTML.dims[8], ""))
          # first.char <- min(which(grepl(">", chars))) + 1
          # chars <- chars[first.char:length(chars)]
          # last.char <- min(which(grepl("<", chars))) - 1
          # chars <- chars[1:last.char]
          # 
          # PTS <- as.numeric(paste(chars, collapse = ""))
          
          # dim #9 has the PPG
          # chars <- unlist(strsplit(HTML.dims[9], ""))
          # first.char <- min(which(grepl(">", chars))) + 1
          # chars <- chars[first.char:length(chars)]
          # last.char <- min(which(grepl("<", chars))) - 1
          # chars <- chars[1:last.char]
          # 
          # PPG <- as.numeric(paste(chars, collapse = ""))
          
          # dim #10 has the PIMS
          chars <- unlist(strsplit(HTML.dims[10], ""))
          first.char <- min(which(grepl(">", chars))) + 1
          chars <- chars[first.char:length(chars)]
          last.char <- min(which(grepl("<", chars))) - 1
          chars <- chars[1:last.char]
          
          PIM <- as.numeric(paste(chars, collapse = ""))
          
          # dim #11 has the +/-
          chars <- unlist(strsplit(HTML.dims[11], ""))
          first.char <- min(which(grepl(">", chars))) + 1
          chars <- chars[first.char:length(chars)]
          last.char <- min(which(grepl("<", chars))) - 1
          chars <- chars[1:last.char]
          
          PLUSMINUS <- as.numeric(paste(chars, collapse = ""))
          
          dataRow <- data.frame(
            playerID = playerID,
            league = league,
            season = as.numeric(season),
            team = teamName,
            GP = GP,
            G = G,
            A = A,
            PTS = G + A,
            PPG = (G + A)/GP,
            PIM = PIM,
            PLUSMINUS = PLUSMINUS
          )
          
          pageData <- rbind(pageData, dataRow)
        }
        
        
      }
    }
    
    
    
    pageData <- pageData %>% filter(!is.na(playerID) & !is.na(GP))
    playerStats <- rbind(playerStats, pageData)
    
    
  }
  
  
  
  return(playerStats)
}

# construct a loop for each season and feed the data in each loop
playerSeasonStats <- data.frame()

for (yr in 2014:2016) {
  playerSeasonStats <- rbind(playerSeasonStats, getLeagueStats(yr, "NHL"))
}

playerIDs <- unique(playerSeasonStats$playerID)

playerDim <- data.frame()

for (id in playerIDs) {
  playerDim <- rbind(playerDim, getPlayerDetails(id))
}